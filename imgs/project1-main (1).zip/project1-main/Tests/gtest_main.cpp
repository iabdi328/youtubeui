/**
 * @file gtest_main.cpp
 * @author ismail
 */

#include <pch.h>
#include "gtest/gtest.h"
#include <wx/wx.h> // Include wxWidgets headers

int main(int argc, char** argv) {
	// Initialize Google Test
	::testing::InitGoogleTest(&argc, argv);

	// Initialize wxWidgets
	if (!wxInitialize()) {
		return -1; // Failed to initialize wxWidgets
	}

	// Run all tests
	int result = RUN_ALL_TESTS();

	// Uninitialize wxWidgets
	wxUninitialize();
	return result;
}
