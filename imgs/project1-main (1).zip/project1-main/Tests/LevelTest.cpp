// LevelTest.cpp
#include <pch.h>
#include <gtest/gtest.h>
#include <wx/filename.h>
#include <wx/filefn.h>
#include <Level.h>

class LevelTest : public ::testing::Test {
protected:
    // Create a temporary path for saving test files
    wxString TempPath() {
        return wxFileName::GetTempDir() + L"/test_level.xml";
    }
};

// Test loading a level from an XML file
TEST_F(LevelTest, LoadFromXML) {
    Level level;
    ASSERT_TRUE(level.LoadFromXML("path/to/your/test_level.xml"));
}

// Test saving a level to an XML file
TEST_F(LevelTest, SaveLevel) {
    Level level;
    auto filePath = TempPath();
    level.Save(filePath);
    ASSERT_TRUE(wxFileExists(filePath));
}

// Test saving and then loading a level
TEST_F(LevelTest, SaveAndLoadLevel) {
    Level level;
    auto filePath = TempPath();
    level.Save(filePath);

    Level loadedLevel;
    ASSERT_TRUE(loadedLevel.LoadFromXML(filePath));
}
