/**
 * @file pch.h
 * @author George Faraj
 *
 *
 */
 
#ifndef PCH_H
#define PCH_H

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#endif //PCH_H
