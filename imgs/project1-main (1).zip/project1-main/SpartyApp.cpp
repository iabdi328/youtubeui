/**
 * @file SpartyApp.cpp
 * @author ismail Abdi
 */

#include "pch.h"
#include "SpartyApp.h"
#include "MainFrame.h"

/**
 * @brief Initializes the main application window.
 */
bool SpartyApp::OnInit() {
 wxInitAllImageHandlers();
 // Create the main frame with the no-argument constructor
 MainFrame* frame = new MainFrame();

 // Call Initialize to set up the frame and menus
 frame->Initialize();

 // Show the frame
 frame->Show(true);

 return true;
}


/**
 * Cleans up resources before the application exits.
 */
int SpartyApp::OnExit() {
 // Perform any necessary cleanup here
 // For example, stop all timers, delete threads, release resources, etc.

 return wxApp::OnExit();  // Call the base class's OnExit to ensure proper cleanup
}
