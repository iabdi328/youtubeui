/**
* @file main.cpp
 * @author Ismail Abdi
 * @brief Entry point for the Sparty's Boots game.
 * @author Brendan Adamski
 */

#include "pch.h"
#include "SpartyApp.h" // Include the SpartyApp from SpartsBootsLib

wxIMPLEMENT_APP(SpartyApp); // Implements the main application entry point