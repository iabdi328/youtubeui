/**
* @file Game.h
 * @author Hector Dominguez Rojas
 * @author Owen Garcia
 * @author George Faraj
 * @author Brendan Adamski
 * @author Ismail Abdi
 */



#ifndef GAME_H
#define GAME_H

#include "Item.h"
#include "Scoreboard.h"
#include "Sensor.h"


/**
 * @class Game
 * @brief Manages the game's state, including items and conveyors.
 */

class ConveyorBelt;
class Beam;

class Game {
private:
	double mScale = 1.0;
	double mXOffset = 0.0;
	double mYOffset = 0.0;
	std::vector<std::shared_ptr<Item>> mItems;
	int mPixelWidth = 1150;  // Default width
	int mPixelHeight = 800;  // Default height

public:
	Game(); ///< Constructor for the Game class
	void Initialize();
	void OnDraw(const std::shared_ptr<wxGraphicsContext>& graphics, int width, int height);
	void AddItem(const std::shared_ptr<Item>& item);
	void LoadItem(std::shared_ptr<Item>& item);
	const std::vector<std::shared_ptr<Item>>& GetItems() const { return mItems; }
	void ClearItems();
	void MoveToFront(std::shared_ptr<Item> item);
	std::shared_ptr<Item> HitTest(wxPoint pos);

	/// New method to get the first ConveyorBelt in the game
	std::shared_ptr<ConveyorBelt> GetConveyorBelt();
	void LoadFromXML(wxXmlNode* node);
};
#endif // GAME_H