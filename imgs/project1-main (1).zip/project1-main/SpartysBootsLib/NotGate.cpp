/**
 * @file NotGate.cpp
 * @author Owen Garcia
 */
#include "pch.h"
#include "NotGate.h"


NotGate::NotGate() : Gate(wxSize(75, 50)) {
    inputPin = new Pin(States::Unknown, wxPoint(-40, 0), false);
    outputPin = new Pin(States::Unknown, wxPoint(40, 0), true);
}

NotGate::~NotGate() {
    delete inputPin;
    delete outputPin;
}

void NotGate::ComputeOutput() {
    States input = inputPin->GetState();

    if (input == States::One) {
        outputPin->SetState(States::Zero);
    } else if (input == States::Zero) {
        outputPin->SetState(States::One);
    } else {
        outputPin->SetState(States::Unknown);
    }
}

void NotGate::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
    auto path = gc->CreatePath();

    auto x = pos.x;
    auto y = pos.y;
    auto w = mSize.GetWidth();
    auto h = mSize.GetHeight();

    wxPoint2DDouble p1(x - w / 2, y - h / 2);
    wxPoint2DDouble p2(x + w / 2 - 10, y);
    wxPoint2DDouble p3(x - w / 2, y + h / 2);

    path.MoveToPoint(p1);
    path.AddLineToPoint(p2);
    path.AddLineToPoint(p3);
    path.CloseSubpath();

    gc->SetPen(*wxBLACK_PEN);
    gc->SetBrush(*wxWHITE_BRUSH);
    gc->DrawPath(path);

    gc->SetBrush(*wxBLACK_BRUSH);
    gc->DrawEllipse(p2.m_x, p2.m_y - 5, 10, 10);

    inputPin->Draw(gc, pos);
    outputPin->Draw(gc, pos);
}

/**
 * Test to see if we hit this object with a mouse.
 * @param pos Position to test.
 * @return true if hit.
 */
bool NotGate::HitTest(wxPoint pos)
{
    // Calculate the position relative to the gate’s center
    int testX = pos.x - GetPosition().x;
    int testY = pos.y - GetPosition().y;

    // Get gate width and height
    int w = mSize.GetWidth();
    int h = mSize.GetHeight();

    // Check if the point is within bounding box (for efficiency)
    if (testX < -w / 2 || testX > w / 2 || testY < -h / 2 || testY > h / 2)
    {
        return false; // Outside bounding box
    }

    // Define points for the triangle approximation
    wxPoint p1(-w / 2, -h / 2);
    wxPoint p2(w / 2 - 10, 0); // Before the output circle
    wxPoint p3(-w / 2, h / 2);

    // Check if point is inside triangle (using barycentric coordinates)
    int denominator = (p2.y - p3.y) * (p1.x - p3.x) + (p3.x - p2.x) * (p1.y - p3.y);
    int a = ((p2.y - p3.y) * (testX - p3.x) + (p3.x - p2.x) * (testY - p3.y)) / denominator;
    int b = ((p3.y - p1.y) * (testX - p3.x) + (p1.x - p3.x) * (testY - p3.y)) / denominator;
    int c = 1 - a - b;

    if (a >= 0 && b >= 0 && c >= 0)
    {
        return true; // Inside triangle
    }

    // Check if within the output circle
    wxPoint outputCenter(p2.x, 0);
    int radius = 5;
    return (pow(testX - outputCenter.x, 2) + pow(testY - outputCenter.y, 2) <= radius * radius);
}
