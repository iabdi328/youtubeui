/**
 * @file Sensor.h
 * @author Hector Dominguez Rojas
 *
 *
 */
 
#ifndef SENSOR_H
#define SENSOR_H

#include "Item.h"


class Sensor : public Item {
private:
    double mX, mY, mHeight, mWidth;
    std::shared_ptr<wxImage> mCameraImage;
    std::shared_ptr<wxImage> mCableImage;

    wxGraphicsBitmap mCamera;
    wxGraphicsBitmap mCable;

public:
    Sensor();
    void Draw(wxGraphicsContext* gc, const wxPoint& pos) override;
    bool IsBroken(double itemX, double itemY, double itemWidth, double itemHeight);
    //bool GetOutput();

    /// Load the sensor properties from an XML node
    bool LoadFromXML(wxXmlNode* node);

    /**
    * Accept a visitor
    * @param visitor The visitor we accept
    */
    // void Accept(ItemVisitor* visitor) override { visitor->VisitSensor(this); }
};



#endif //SENSOR_H
