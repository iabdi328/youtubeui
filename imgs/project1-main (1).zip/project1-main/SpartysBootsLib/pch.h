/**
 * @file pch.h
 * @author George Faraj
 * @author Ismail Abdi
 *
 *
 */
 
#ifndef PCH_H
#define PCH_H

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#include <wx/graphics.h>
#include <wx/sound.h>
#include <wx/xml/xml.h>
#include <wx/tokenzr.h>
#include <wx/dcbuffer.h>
#include <wx/filename.h>
#include <wx/filefn.h>
#include <wx/string.h>
#include <wx/colour.h>
#include <wx/gdicmn.h>
#include <wx/log.h>
#include <wx/image.h>

#include <filesystem>
#include <memory>
#include <cmath>
#include <vector>
#include <random>

#endif // PCH_H
