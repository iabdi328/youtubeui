/**
 * @file NotGate.h
 * @author Owen Garcia
 */

#ifndef NOTGATE_H
#define NOTGATE_H

#include "Gate.h"
#include "Pin.h"

class NotGate : public Gate {
public:
	NotGate();
	~NotGate() override;

	void ComputeOutput() override;
	void Draw(wxGraphicsContext* gc, const wxPoint& pos) override;
	bool HitTest(wxPoint pos);

private:
	Pin* inputPin;
	Pin* outputPin;
};

#endif // NOTGATE_H
