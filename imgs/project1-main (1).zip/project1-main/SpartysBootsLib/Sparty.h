/**
 * @file Sparty.h
 * @author George Faraj
 *
 * Class for Sparty that kicks products off the conveyor belt when triggered
 * by an input pin. The class handles the kick animation, including a rotating boot
 * and product movement calculations.
 */

#ifndef SPARTY_H
#define SPARTY_H

#include "Item.h"

class Sparty : public Item {
private:
    /// Position and dimensions
    double mX, mY, mHeight, mWidth;

    /// Kick animation parameters
    double mKickDuration;
    double mKickSpeed;
    double mKickTime = 0;

    /// Pin location
    double mPinX;
    double mPinY;

    /// Previous pin state for edge detection
    bool mPrevPinState = false;

    /// Component images
    std::shared_ptr<wxImage> mBackImage;
    std::shared_ptr<wxImage> mBootImage;
    std::shared_ptr<wxImage> mFrontImage;

    /// Graphics bitmaps
    wxGraphicsBitmap mBack;
    wxGraphicsBitmap mBoot;
    wxGraphicsBitmap mFront;

    /// Maximum offset of Bezier control points relative to line ends
    static constexpr double BezierMaxOffset = 200;

    /// Line with for drawing lines between pins
    static const int LineWidth = 3;

    /// Default length of line from the pin
    static const int DefaultLineLength = 20;

    /// Draw the input pin and connection line
    void DrawPin(wxGraphicsContext* gc);

public:
    Sparty();
    void Draw(wxGraphicsContext* gc, const wxPoint& pos) override;
    bool LoadFromXML(wxXmlNode* node);
    void SetPinState(bool state);
    bool ShouldKickProduct(double productX, double productY) const;
    void Update(double elapsed);

    /// Get pin position
    wxPoint GetPinPosition() const { return wxPoint(mPinX, mPinY); }

    /**
    * Accept a visitor
    * @param visitor The visitor we accept
    */
    // void Accept(ItemVisitor* visitor) override { visitor->VisitSparty(this); }
};


#endif //SPARTY_H
