/**
 * @file Sensor.cpp
 * @author Hector Dominguez Rojas
 */

#include "pch.h"
#include "Sensor.h"


Sensor::Sensor()
{
 mCameraImage = std::make_shared<wxImage>(L"images/sensor-camera.png");
 mCableImage = std::make_shared<wxImage>(L"images/sensor-cable.png");
}

void Sensor::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
 if (!mCameraImage->IsOk() || !mCableImage->IsOk()) {
  return;
 }

 // Lazy initialization of the bitmaps
 if (mCamera.IsNull()) {
  mCamera = gc->CreateBitmapFromImage(*mCameraImage);
 }
 if (mCable.IsNull()) {
  mCable = gc->CreateBitmapFromImage(*mCableImage);
 }

 int width = mCameraImage->GetWidth();
 int height = mCameraImage->GetHeight();
 /// Range where a product is viewed by the sensor relative
 /// to the Y coordinate of the sensor.
 const int SensorRange[] = {-40, 15};

 //Draw Camera
 gc->PushState();
 gc->DrawBitmap(mCamera, mX - width/2, mY - height/2, width, height);
 gc->PopState();

 width = mCableImage->GetWidth();
 height = mCableImage->GetHeight();
 // Draw Receiver as mirrored Sender image
 gc->PushState();  // Save current state before transforming for receiver
// gc->Translate(mX + width/2, mY);  // Move the origin to the center of the second image
// gc->Scale(-1, 1);  // Flip/mirror the image
 gc->DrawBitmap(mCable, mX - width/2, mY - height/2, width, height);  // Draw at the new origin
 gc->PopState();   // Restore state after drawing the receiver

 // Draw lines indicating sensor range
 //gc->SetPen(*wxRED_PEN);
 // gc->StrokeLine(mX - width/2, mY + SensorRange[0], mX + width/2, mY + SensorRange[0] );
 //gc->StrokeLine(mX - width/2, mY + SensorRange[1], mX + width/2, mY + SensorRange[1] );
}

bool Sensor::LoadFromXML(wxXmlNode* node)
{
 if (node->GetName() != L"sensor") {
  return false;
 }
 long x, y;

 //Load and set Beam attributes from XML node
 node->GetAttribute(L"x", L"0").ToLong(&x);
 node->GetAttribute(L"y", L"0").ToLong(&y);

 mX = static_cast<int>(x);
 mY = static_cast<int>(y);

 return true;
}