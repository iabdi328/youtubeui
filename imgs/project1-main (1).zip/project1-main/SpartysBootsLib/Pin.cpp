/**
 * @file Pin.cpp
 * @author Owen Garcia
 */
#include "pch.h"
#include "Pin.h"


const int PinRadius = 5;

bool Pin::HitTest(int x, int y) const {
	int dx = x - mLocation.x;
	int dy = y - mLocation.y;
	return (dx * dx + dy * dy) <= PinRadius * PinRadius;
}

void Pin::StartDragging(int x, int y) {
	if (mIsOutput) {
		mDragging = true;
		mWireEnd = wxPoint(x, y);
	}
}

void Pin::SetWireEnd(int x, int y) {
	if (mDragging) {
		mWireEnd = wxPoint(x, y);
	}
}

void Pin::StopDragging() {
	mDragging = false;
	mWireEnd = mLocation; // Reset wire end position
}

void Pin::ConnectTo(Pin* inputPin) {
	if (!mIsOutput || inputPin->IsOutput()) return;

	if (inputPin->mConnectedPin) {
		inputPin->mConnectedPin->mConnectedPin = nullptr; // Remove any existing connection
	}

	mConnectedPin = inputPin;
	inputPin->mConnectedPin = this;
}

void Pin::Draw(wxGraphicsContext* gc, const wxPoint& gatePos) const {
	wxPoint pinPos = mLocation + gatePos;
	gc->SetBrush(*wxGREEN_BRUSH);
	gc->DrawEllipse(pinPos.x - PinRadius, pinPos.y - PinRadius, PinRadius * 2, PinRadius * 2);

	if (mDragging || mConnectedPin) {
		gc->SetPen(*wxBLACK_PEN);
		wxPoint p1 = pinPos;
		wxPoint p4 = mDragging ? mWireEnd : (mConnectedPin->mLocation + gatePos);
		double offset = std::min(BezierMaxOffset, std::abs(p4.x - p1.x) / 2.0);

		wxPoint p2 = wxPoint(p1.x + offset, p1.y);
		wxPoint p3 = wxPoint(p4.x - offset, p4.y);

		gc->StrokeLine(p1.x, p1.y, p2.x, p2.y); // Draw Bézier control points for simplicity
		gc->StrokeLine(p3.x, p3.y, p4.x, p4.y);
	}
}