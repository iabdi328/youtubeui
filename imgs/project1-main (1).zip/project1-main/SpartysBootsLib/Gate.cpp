/**
 * @file Gate.cpp
 * @author Owen Garcia
 */
#include "pch.h"
#include "Gate.h"

void Gate::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
    // Base class doesn't draw, but derived classes will override this
}

/**
 * Handle updates for the gate.
 *
 * @param elapsed Time elapsed since the class call
 */
void Gate::Update(double elapsed)
{
	SetPosition(GetPosition());
}