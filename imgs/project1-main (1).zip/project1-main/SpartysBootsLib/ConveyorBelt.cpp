/**
* @file ConveyorBelt.cpp
 * @author Ismail Abdi
 * @author Brendan Adamski
 * @author Owen Garcia
 */

#include "pch.h"
#include "ConveyorBelt.h"
#include "Product.h"


using namespace std;

/// Initial product X and Y positions
const int InitialX = 100;
const int InitialY = 50;

/**
 * Constructor
 */
ConveyorBelt::ConveyorBelt() : mConveyorLoopSound("Sounds/conveyor_loop.wav"), mIsSoundPlaying(false) {
    mBeltPositionY = 400;

    // Load images for the conveyor belt and control panel
    mBackgroundImage = std::make_shared<wxImage>();
    mBackgroundImage->LoadFile("images/conveyor-back.png", wxBITMAP_TYPE_PNG);

    mBeltImage = std::make_shared<wxImage>();
    mBeltImage->LoadFile("images/conveyor-belt.png", wxBITMAP_TYPE_PNG);

    mPanelStoppedImage = std::make_shared<wxImage>();
    mPanelStoppedImage->LoadFile("images/conveyor-switch-stop.png", wxBITMAP_TYPE_PNG);

    mPanelStartedImage = std::make_shared<wxImage>();
    mPanelStartedImage->LoadFile("images/conveyor-switch-start.png", wxBITMAP_TYPE_PNG);

    // Initially set the panel to show the "stop" image
    mPanelBitmap = wxGraphicsBitmap();

    random_device rd;
    mRandom.seed(rd());
}

/**
 * Draw the conveyor belt and its components
 */
void ConveyorBelt::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
    if (!mBackgroundImage->IsOk() || !mBeltImage->IsOk() || !mPanelStoppedImage->IsOk() || !mPanelStartedImage->IsOk()) {
        return;
    }

    if (mBackgroundBitmap.IsNull()) {
        mBackgroundBitmap = gc->CreateBitmapFromImage(*mBackgroundImage);
    }
    if (mBeltBitmap.IsNull()) {
        mBeltBitmap = gc->CreateBitmapFromImage(*mBeltImage);
    }

    // Update mPanelBitmap to either mPanelStartedImage or mPanelStoppedImage based on mIsStarted
    if (mIsStarted) {
        mPanelBitmap = gc->CreateBitmapFromImage(*mPanelStartedImage);
    } else {
        mPanelBitmap = gc->CreateBitmapFromImage(*mPanelStoppedImage);
    }

    gc->DrawBitmap(mBackgroundBitmap, mPosition.x - mWidth / 2, mPosition.y - mHeight / 2, mWidth, mHeight);
    gc->DrawBitmap(mBeltBitmap, mPosition.x - mWidth / 2, mBeltPositionY % mHeight - mHeight, mWidth, mHeight);
    if (mBeltPositionY % mHeight != 0) {
        gc->DrawBitmap(mBeltBitmap, mPosition.x - mWidth / 2, mBeltPositionY % mHeight, mWidth, mHeight);
    }

    // Draw updated panel image based on mIsStarted
    gc->DrawBitmap(mPanelBitmap, mPosition.x + mPanelLocation.x, mPosition.y + mPanelLocation.y, 100, 100);
    gc->SetPen(wxPen(*wxBLACK, 2));

    for (const auto& product : mProducts) {
        product->Draw(gc, pos);
    }
}

/**
 * Handle start/stop button clicks and update panel state
 */
void ConveyorBelt::OnClick(wxMouseEvent& event) {
    int localX = event.GetX() - mPosition.x - mPanelLocation.x;
    int localY = event.GetY() - mPosition.y - mPanelLocation.y;

    if (StartButtonRect.Contains(localX, localY) && !mIsStarted) {
        mIsStarted = true;

        // Play start sound
        wxSound startSound("Sounds/start_sound.wav");
        if (startSound.IsOk()) startSound.Play(wxSOUND_ASYNC);

        // Play conveyor loop sound if it isn't already playing
        if (!mIsSoundPlaying && mConveyorLoopSound.IsOk()) {
            mConveyorLoopSound.Play(wxSOUND_ASYNC | wxSOUND_LOOP);
            mIsSoundPlaying = true;
        }

    } else if (StopButtonRect.Contains(localX, localY) && mIsStarted) {
        mIsStarted = false;

        // Play stop sound
        wxSound stopSound("Sounds/stop_sound.wav");
        if (stopSound.IsOk()) stopSound.Play(wxSOUND_ASYNC);

        // Stop the conveyor loop sound if it is playing
        if (mIsSoundPlaying) {
            mConveyorLoopSound.Stop();
            mIsSoundPlaying = false;
        }
    }
}

/**
 * Add a product to the conveyor belt
 * @param product The product to add
 */
void ConveyorBelt::Add(const shared_ptr<Product>& product) {
    product->SetLocation(InitialX, InitialY);
    mProducts.push_back(product);
}

/**
 * Clear the conveyor belt (remove all products)
 */
void ConveyorBelt::Clear() {
    mProducts.clear();
}

/**
 * Load the conveyor belt properties from an XML node
 * @param node The XML node
 * @return True if successful, false otherwise
 */
bool ConveyorBelt::LoadFromXML(wxXmlNode* node) {
    if (node->GetName() != L"conveyor") {
        return false;
    }

    // Clear existing products
    Clear();

    // Set conveyor position, dimensions, and speed from XML attributes
    long x, y, height, speed;
    wxString panelLocation;

    node->GetAttribute(L"x", L"0").ToLong(&x);
    node->GetAttribute(L"y", L"0").ToLong(&y);
    node->GetAttribute(L"height", L"100").ToLong(&height);
    node->GetAttribute(L"speed", L"100").ToLong(&speed);
    panelLocation = node->GetAttribute(L"panel", L"0,0");

    mPosition = wxPoint(static_cast<int>(x), static_cast<int>(y));
    mHeight = static_cast<int>(height);
    mSpeed = static_cast<int>(speed);

    // Maintain the aspect ratio of the belt image
    double aspectRatio = mBeltImage->IsOk() ? static_cast<double>(mBeltImage->GetWidth()) / mBeltImage->GetHeight() : 1.0;
    mWidth = static_cast<int>(mHeight * aspectRatio);
    mOriginalWidth = mWidth;
    mOriginalHeight = mHeight;
    // Set panel location from the XML
    wxStringTokenizer tokenizer(panelLocation, L",");
    tokenizer.GetNextToken().ToLong(&x);
    tokenizer.GetNextToken().ToLong(&y);
    mPanelLocation = wxPoint(static_cast<int>(x), static_cast<int>(y));

    // Load products from the XML
    auto child = node->GetChildren();
    while (child) {
        if (child->GetName() == L"product") {
            XmlProduct(child);
        }
        child = child->GetNext();
    }
    return true;
}

/**
 * Update product positions for animation
 * @param elapsed The time since the last update
 */
void ConveyorBelt::Update(double elapsed) {
    if (mIsStarted) {
        mBeltPositionY += static_cast<int>(mSpeed * elapsed);
        if (mBeltPositionY >= mHeight) {
            mBeltPositionY -= mHeight;
        }
    }

    for (auto& product : mProducts) {
        product->Update(elapsed, mIsStarted);  // Pass mIsStarted to each product's Update method
        bool broken = mBeam->IsBroken(product);
        mBeam->Update(broken);
    }
}

/**
 * Handle loading a product from an XML node
 * @param node The XML node
 */
void ConveyorBelt::XmlProduct(wxXmlNode* node) {
    // Define your product loading logic here.
}

bool ConveyorBelt::IsWithinBounds(const wxPoint& pos) const {
    // Check if pos is within the conveyor’s position and dimensions
    return wxRect(0, 0, 1000, 1000).Contains(pos);
}

bool ConveyorBelt::IsStarted() const {
    return mIsStarted;
}

/**
 * Destructor for ConveyorBelt.
 */
ConveyorBelt::~ConveyorBelt() {
    if (mIsSoundPlaying) {
        mConveyorLoopSound.Stop();
        mIsSoundPlaying = false;
    }
}
