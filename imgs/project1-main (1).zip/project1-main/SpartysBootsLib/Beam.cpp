/**
 * @file Beam.cpp
 * @author Hector Dominguez Rojas
 */

#include "pch.h"
#include "Beam.h"


Beam::Beam()
{
 mGreenImage = std::make_shared<wxImage>(L"images/beam-green.png");
 mRedImage = std::make_shared<wxImage>(L"images/beam-red.png");
 mImage = mGreenImage;
}
// Draw the beam with wxPen
void Beam::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
 if (!mGreenImage->IsOk() || !mRedImage->IsOk()) {
  return;
 }
 // Lazy initialization of the bitmaps
 if (mSender.IsNull()) {
  mSender = gc->CreateBitmapFromImage(*mImage);
 }
 if (mReceiver.IsNull()) {
  mReceiver = gc->CreateBitmapFromImage(*mImage);
 }

 int width = mImage->GetWidth();
 int height = mImage->GetHeight();

 //Draw Sender
 gc->PushState();
 gc->DrawBitmap(mSender, (mX - 185) - width/2, mY - height/2, width, height);
 gc->PopState();

 // Draw Receiver as mirrored Sender image
 gc->PushState();  // Save current state before transforming for receiver
 gc->Translate(mX + width, mY);  // Move the origin to the center of the second image
 gc->Scale(-1, 1);  // Flip/mirror the image
 gc->DrawBitmap(mReceiver, width/2, -height / 2, width, height);  // Draw at the new origin
 gc->PopState();   // Restore state after drawing the receiver

 wxPen laser1(wxColour(255, 200, 200, 100), 8);  // Soft pink, semi-transparent, thick
 wxPen laser2(wxColour(255, 0, 0, 175), 4);      // Red, less transparent, thinner

 gc->SetPen(laser1);
 gc->StrokeLine(mX-width/2, mY, (mX - 185) + width/2, mY);  // Draw the outer beam

 gc->SetPen(laser2);
 gc->StrokeLine(mX-width/2, mY, (mX - 185) + width/2, mY);  // Draw the inner core of the beam
}

bool Beam::IsBroken(const std::shared_ptr<Product>& product)
{
 int y = product->GetPlacement();
 int height = mImage->GetHeight();
 if(y > mY - height/2 && y < mY + height/2)
 {
  return true;
 }
 return false;

}

void Beam::Update(bool state)
{
 if (state==mOutput)
 {
  return;
 }else
 {
  if (state)
  {
   mImage = mRedImage;
   mOutput = state;
  }else
  {
   mImage = mGreenImage;
   mOutput = state;
  }
 }
}

bool Beam::LoadFromXML(wxXmlNode* node)
{
 if (node->GetName() != L"beam") {
        return false;
    }
 long x, y;

 //Load and set Beam attributes from XML node
 node->GetAttribute(L"x", L"0").ToLong(&x);
 node->GetAttribute(L"y", L"0").ToLong(&y);

 mX = static_cast<int>(x);
 mY = static_cast<int>(y);

 return true;
}

