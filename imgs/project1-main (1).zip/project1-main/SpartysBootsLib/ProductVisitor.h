/**
 * @file ProductVisitor.h
 * @author Hector Dominguez Rojas
 *
 *
 */
 
#ifndef PRODUCTVISITOR_H
#define PRODUCTVISITOR_H



class ProductVisitor {
private:

public:

};



#endif //PRODUCTVISITOR_H
