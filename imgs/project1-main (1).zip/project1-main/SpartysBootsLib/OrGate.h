/**
 * @file OrGate.h
 * @author Owen Garcia
 */

#ifndef ORGATE_H
#define ORGATE_H

#include "Gate.h"
#include "Pin.h"

class OrGate : public Gate {
public:
	OrGate();
	~OrGate() override;

	void ComputeOutput() override;
	void Draw(wxGraphicsContext* gc, const wxPoint& pos) override;
	bool HitTest(wxPoint pos);

private:
	Pin* inputPin1;
	Pin* inputPin2;
	Pin* outputPin;
};

#endif // ORGATE_H
