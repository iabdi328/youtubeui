/**
* @file MainFrame.h
 * @brief The top-level (main) frame of the Sparty's Boots application.
 * @author Ismail Abdi
 * @author Owen Garcia
 */

#ifndef _MAINFRAME_H_
#define _MAINFRAME_H_


class GameView;

/**
 * @class MainFrame
 * @brief The MainFrame class is responsible for creating the main window of the application.
 */
class MainFrame : public wxFrame
{
public:
	// Constructor
//	MainFrame();

	// Custom initialization method
	void Initialize();

private:
	GameView* mGameView;

	// Event handlers
	void OnExit(wxCommandEvent& event);
	void OnAbout(wxCommandEvent& event);
	void OnClose(wxCloseEvent& event);
	void OnLoadLevel(wxCommandEvent& event); // Event handler for loading levels

	wxDECLARE_EVENT_TABLE();
};


#endif //_MAINFRAME_H_
