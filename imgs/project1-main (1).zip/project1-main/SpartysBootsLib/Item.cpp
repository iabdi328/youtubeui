/**
 * @file Item.cpp
 * @author Owen Garcia
 */
#include "pch.h"
#include "item.h"

bool Item::IsWithinBounds(const wxPoint& pos) const {
	// Check if pos is within the conveyor’s position and dimensions
	return wxRect(0, 0, 1000, 1000).Contains(pos);
}