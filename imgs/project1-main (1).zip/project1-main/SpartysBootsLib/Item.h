/**
 * @file Item.h
 * @author Owen Garcia
 *
 * Base class for all items in the game.
 */

#ifndef ITEM_H
#define ITEM_H
#include "ItemVisitor.h"


class Item {
public:
    Item() = default;
    virtual ~Item() = default;

    // Virtual draw method that derived classes will override
    virtual void Draw(wxGraphicsContext* gc, const wxPoint& pos) = 0;

	/**
	 * The position.
	 * @returns wxPoint containing the position
	 */
	[[nodiscard]] wxPoint GetPosition() { return mPosition; }

	/**
	 * Set the item location
	 * @param x X location in pixels
	 * @param y Y location in pixels
	 */
	virtual void SetPosition(wxPoint pos) { mPosition = pos; }

	/**
	 * Handle updates for animation
	 * @param elapsed The time since the last update
	 */
	virtual void Update(double elapsed) {}

	/**
	 * Test to see if we hit this object with a mouse.
	 * Will be overriden by the Gate class's version.
	 * @param pos A point to test for.
	 */
	virtual bool HitTest(wxPoint pos) { return false; }

	bool IsWithinBounds(const wxPoint& pos) const;

	virtual void Accept(ItemVisitor* visitor) =0;

protected:
	wxPoint mPosition;
};

#endif // ITEM_H