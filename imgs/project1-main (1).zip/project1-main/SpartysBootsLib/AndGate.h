/**
 * @file AndGate.h
 * @author Owen Garcia
 */

#ifndef ANDGATE_H
#define ANDGATE_H

#include "Gate.h"
#include "Pin.h"

class AndGate : public Gate {
public:
	AndGate();
	~AndGate() override;

	void ComputeOutput() override;
	void Draw(wxGraphicsContext* gc, const wxPoint& pos) override;
	bool HitTest(wxPoint pos);
	// std::shared_ptr<Pin> HitTest(int x, int y);

private:
	Pin* inputPin1;
	Pin* inputPin2;
	Pin* outputPin;
};

#endif // ANDGATE_H