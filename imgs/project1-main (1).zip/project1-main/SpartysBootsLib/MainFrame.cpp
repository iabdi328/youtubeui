/**
 * @author Ismail Abdi
 * @file MainFrame.cpp
 * @brief Implementation of the MainFrame class.
*  @author Ismail Abdi
 * @author Owen Garcia
 */

#include "pch.h"
#include "MainFrame.h"
#include "GameView.h"
#include "ids.h"

wxBEGIN_EVENT_TABLE(MainFrame, wxFrame)
    EVT_MENU(wxID_EXIT, MainFrame::OnExit)
    EVT_MENU(wxID_ABOUT, MainFrame::OnAbout)
    EVT_MENU_RANGE(IDM_LOAD_LEVEL0, IDM_LOAD_LEVEL8, MainFrame::OnLoadLevel)
wxEND_EVENT_TABLE()

/**
 * Initializes MainFrame with custom settings.
 */
void MainFrame::Initialize() {
    Create(nullptr, wxID_ANY, "Sparty's Boots", wxDefaultPosition, wxSize(1200, 900));
    auto sizer = new wxBoxSizer(wxVERTICAL);

	// Set the icon for the application window
	wxIcon icon;
	icon.LoadFile("images/SpartysBoots.ico", wxBITMAP_TYPE_ICO);  // Replace with "app_icon.png" and wxBITMAP_TYPE_PNG if using PNG
	SetIcon(icon);  // Set the icon to the frame


    mGameView = new GameView();
    mGameView->Initialize(this);
    sizer->Add(mGameView, 1, wxEXPAND | wxALL);

    SetSizer(sizer);
    Layout();

    CreateStatusBar();
    SetStatusText("Welcome to Sparty's Boots!");

    auto menuBar = new wxMenuBar();
    auto fileMenu = new wxMenu();
    auto levelsMenu = new wxMenu();
    auto gateMenu = new wxMenu();
    auto helpMenu = new wxMenu();

    fileMenu->Append(wxID_EXIT, "E&xit\tAlt-X", "Quit the program");

    for (int i = 0; i <= 8; i++) {
        wxString levelLabel = wxString::Format("Level %d", i);
        levelsMenu->Append(IDM_LOAD_LEVEL0 + i, levelLabel);
    }

    gateMenu->Append(IDM_ADDGATEOR, "OR Gate", "Add an OR gate");
    gateMenu->Append(IDM_ADDGATEAND, "AND Gate", "Add an AND gate");
    gateMenu->Append(IDM_ADDGATENOT, "NOT Gate", "Add a NOT gate");

    helpMenu->Append(wxID_ABOUT, "&About\tF1", "Show about dialog");

    Bind(wxEVT_COMMAND_MENU_SELECTED, &MainFrame::OnExit, this, wxID_EXIT);
    Bind(wxEVT_COMMAND_MENU_SELECTED, &MainFrame::OnAbout, this, wxID_ABOUT);
    Bind(wxEVT_CLOSE_WINDOW, &MainFrame::OnClose, this);

    menuBar->Append(fileMenu, "&File");
    menuBar->Append(levelsMenu, "&Levels");
    menuBar->Append(gateMenu, "&Gates");
    menuBar->Append(helpMenu, "&Help");

    SetMenuBar(menuBar);

    // Load Level 0 by default
    wxCommandEvent loadLevel0Event(wxEVT_MENU, IDM_LOAD_LEVEL0);
    OnLoadLevel(loadLevel0Event);
}

/**
 * Handles level loading events.
 */
void MainFrame::OnLoadLevel(wxCommandEvent& event) {
    int levelIndex = event.GetId() - IDM_LOAD_LEVEL0;
    wxString levelFile = wxString::Format("%s/levels/level%d.xml", wxGetCwd(), levelIndex);

    if (!mGameView->LoadFromXML(levelFile)) {
        SetStatusText(wxString::Format("Failed to load Level %d", levelIndex));
    } else {
        SetStatusText(wxString::Format("Loaded Level %d", levelIndex));
    }
}

/**
 * Handles the exit event.
 */
void MainFrame::OnExit(wxCommandEvent& event) {
    Close(true);
}

/**
 * Handles the about dialog event.
 */
void MainFrame::OnAbout(wxCommandEvent& event) {
    wxMessageBox("Welcome to Sparty's Boots!",
                 "About Sparty's Boots", wxOK | wxICON_INFORMATION);
}

/**
 * Handles the window close event.
 */
void MainFrame::OnClose(wxCloseEvent& event) {
    if (mGameView) {
        mGameView->Destroy();
        mGameView = nullptr;
    }
    Destroy();
}
