/**
 * @file Scoreboard.cpp
 * @author George Faraj
 * @author Brendan Adamski
 */

#include "pch.h"
#include "Scoreboard.h"


Scoreboard::Scoreboard() : mLevelState(1), mGameScore(0), mGoodScore(0), mBadScore(0)
{
    mInstruction = "Default instructions.";
}

void Scoreboard::Draw(wxGraphicsContext* graphics, const wxPoint& pos)
{
    double posX = pos.x;
    double posY = pos.y;
    double padding = 10.0;

    graphics->PushState();

    graphics->SetBrush(*wxWHITE_BRUSH);
    graphics->SetPen(wxPen(wxColour(0, 0, 0), 3));
    graphics->DrawRectangle(posX, posY, ScoreboardSize.GetWidth(), ScoreboardSize.GetHeight());

    DrawText(graphics, wxString::Format("Level: %d", mLevelState), posX + padding, posY + padding, 25,
             wxColour(24, 69, 59));
    DrawText(graphics, wxString::Format("Game: %d", mGoodScore), posX + ScoreboardSize.GetWidth() / 2,
             posY + padding, 25, wxColour(24, 69, 59));
    DrawText(graphics, mInstruction, posX + padding, posY + padding + SpacingScoresToInstructions, 15, *wxBLACK);

    graphics->PopState();
}

void Scoreboard::DrawText(wxGraphicsContext* graphics, const wxString& text, double x, double y, int fontSize,
                          const wxColour& color)
{
    graphics->SetFont(graphics->CreateFont(fontSize, L"Arial", wxFONTFLAG_BOLD, color));
    graphics->DrawText(text, x, y);
}

void Scoreboard::LoadFromXML(wxXmlNode* node)
{
}

// Setter implementations
void Scoreboard::SetPosition(const wxPoint& pos)
{
    Item::SetPosition(pos);
}

void Scoreboard::SetGoodScore(int score)
{
    mGoodScore = score;
}

void Scoreboard::SetBadScore(int score)
{
    mBadScore = score;
}

void Scoreboard::SetInstruction(const wxString& instruction)
{
    mInstruction = instruction;
}

void Scoreboard::SetLevelState(int levelState)
{
    mLevelState = levelState;
}
