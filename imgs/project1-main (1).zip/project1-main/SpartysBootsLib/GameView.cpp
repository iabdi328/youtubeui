/**
 * @file GameView.cpp
 * @author Ismail Abdi
 * @author Owen Garcia
 * @author Brendan Adamski
 */

#include "pch.h"
#include "ids.h"
#include "GameView.h"
#include "OrGate.h"
#include "AndGate.h"
#include "NotGate.h"
#include "ConveyorBelt.h"
#include "Product.h"
#include "Sparty.h"


wxPoint mDragOffset;

//GameView::GameView(wxFrame* parent)
//    : wxWindow(parent, wxID_ANY)
//{
// Set a simple background color for now
// SetBackgroundColour(*wxWHITE);
//}

void GameView::Initialize(wxFrame* parent)
{
    Create(parent, wxID_ANY,
           wxDefaultPosition, wxDefaultSize,
           wxFULL_REPAINT_ON_RESIZE);
    SetBackgroundStyle(wxBG_STYLE_PAINT);
    Bind(wxEVT_PAINT, &GameView::OnPaint, this);
    Bind(wxEVT_TIMER, &GameView::OnTimer, this);
    parent->Bind(wxEVT_COMMAND_MENU_SELECTED, &GameView::OnOrGate, this, IDM_ADDGATEOR);
    parent->Bind(wxEVT_COMMAND_MENU_SELECTED, &GameView::OnAndGate, this, IDM_ADDGATEAND);
    parent->Bind(wxEVT_COMMAND_MENU_SELECTED, &GameView::OnNotGate, this, IDM_ADDGATENOT);

    // Bind mouse events
    Bind(wxEVT_LEFT_DOWN, &GameView::OnMouseDown, this);
    Bind(wxEVT_LEFT_UP, &GameView::OnMouseUp, this);
    Bind(wxEVT_MOTION, &GameView::OnMouseMove, this);

    // Start the timer (refresh rate in milliseconds, e.g., 16 ms for ~60 FPS)
    mTimer.SetOwner(this);
    mTimer.Start(16);
}

void GameView::OnMouseDown(wxMouseEvent& event)
{
    mGrabbedItem = mGame.HitTest(event.GetPosition());
    wxPoint pos = event.GetPosition();

    // Check if the click intersects with any conveyor belt item
    for (auto& item : mGame.GetItems())
    {
        auto conveyorBelt = std::dynamic_pointer_cast<ConveyorBelt>(item);
        if (conveyorBelt && conveyorBelt->IsWithinBounds(pos))
        {
            conveyorBelt->OnClick(event);
            break;
        }
        // if (item->IsWithinBounds(pos) && !conveyorBelt->IsWithinBounds(pos))
        // {
        //     mGrabbedItem = item;
        //     mDragOffset = pos - item->GetPosition();
        //     Refresh();
        //     break;
        // }
    }

    if (mGrabbedItem != nullptr)
    {
        mGame.MoveToFront(mGrabbedItem);
    }
}

void GameView::OnMouseUp(wxMouseEvent& event)
{
    mGrabbedItem = nullptr; // Release the dragged item
}

void GameView::OnMouseMove(wxMouseEvent& event)
{
    // See if an item is currently being moved by the mouse
    if (mGrabbedItem != nullptr)
    {
        // If an item is being moved, we only continue to
        // move it while the left button is down.
        if (event.LeftIsDown())
        {
            mGrabbedItem->SetPosition(event.GetPosition());
        }
        else
        {
            // When the left button is released, we release the
            // item.
            mGrabbedItem = nullptr;
        }

        // Force the screen to redraw
        Refresh();
    }
}

void GameView::OnPaint(wxPaintEvent& event)
{
    // Create a double-buffered display context
    wxAutoBufferedPaintDC dc(this);

    // Clear the image to black
    wxBrush background(*wxBLACK);
    dc.SetBackground(background);
    dc.Clear();

    // Create a graphics context
    auto gc = std::shared_ptr<wxGraphicsContext>(wxGraphicsContext::Create(dc));

    // Tell the game class to draw everything, including the conveyor belt
    wxRect rect = GetRect();
    mGame.OnDraw(gc, rect.GetWidth(), rect.GetHeight());
}

/**
 * @brief Handles the addition of an OR gate.
 * @param event The wxCommandEvent that triggered the handler.
 */
void GameView::OnOrGate(wxCommandEvent& event)
{
    auto orGate = std::make_shared<OrGate>();
    wxPoint initialPosition(400, 400);
    orGate->SetPosition(initialPosition);
    mGame.AddItem(orGate);
    Refresh();
}

/**
 * @brief Handles the addition of an AND gate.
 * @param event The wxCommandEvent that triggered the handler.
 */
void GameView::OnAndGate(wxCommandEvent& event)
{
    auto andGate = std::make_shared<AndGate>();
    wxPoint initialPosition(400, 500);
    andGate->SetPosition(initialPosition);
    mGame.AddItem(andGate);
    Refresh();
}

/**
 * @brief Handles the addition of a NOT gate.
 * @param event The wxCommandEvent that triggered the handler.
 */
void GameView::OnNotGate(wxCommandEvent& event)
{
    auto notGate = std::make_shared<NotGate>();
    wxPoint initialPosition(400, 600);
    notGate->SetPosition(initialPosition);
    mGame.AddItem(notGate);
    Refresh();
}

bool GameView::LoadFromXML(const wxString& filePath)
{
    wxXmlDocument xmlDoc;
    if (!xmlDoc.Load(filePath))
    {
        return false;
    }

    if (!xmlDoc.GetRoot()->GetName().IsSameAs("level"))
    {
        return false;
    }



    mGame.ClearItems();
    wxString fileName = wxFileName(filePath).GetName();
    int levelState = wxAtoi(fileName.Right(1));

    wxXmlNode* itemsNode = xmlDoc.GetRoot()->GetChildren();
    if (!itemsNode || !itemsNode->GetName().IsSameAs("items"))
    {
        return false;
    }



    wxXmlNode* itemNode = itemsNode->GetChildren();
    while (itemNode)
    {
        wxString nodeName = itemNode->GetName();

        if (itemNode->GetName().IsSameAs("scoreboard"))
        {
            auto scoreboard = std::make_shared<Scoreboard>();
            scoreboard->SetLevelState(levelState);

            // Set other attributes as before
            wxString x = itemNode->GetAttribute("x", "0");
            wxString y = itemNode->GetAttribute("y", "0");
            wxString good = itemNode->GetAttribute("good", "0");
            wxString bad = itemNode->GetAttribute("bad", "0");
            wxString words = itemNode->GetNodeContent();
            scoreboard->SetPosition(wxPoint(wxAtoi(x), wxAtoi(y)));
            scoreboard->SetGoodScore(wxAtoi(good));
            scoreboard->SetBadScore(wxAtoi(bad));
            scoreboard->SetInstruction(words);
            mGame.AddItem(scoreboard);
        }


        if (nodeName.IsSameAs("conveyor"))
        {
            wxString x = itemNode->GetAttribute("x", "0");
            wxString y = itemNode->GetAttribute("y", "0");
            wxString speed = itemNode->GetAttribute("speed", "0");


            auto conveyor = std::make_shared<ConveyorBelt>();
            conveyor->LoadFromXML(itemNode);
            mGame.AddItem(conveyor);

            wxXmlNode* productNode = itemNode->GetChildren();
            int placementSum = 0; // Initialize the placement sum

            while (productNode)
            {
                if (productNode->GetName().IsSameAs("product"))
                {
                    wxString placement = productNode->GetAttribute("placement", "0");
                    wxString shape = productNode->GetAttribute("shape", "");
                    wxString color = productNode->GetAttribute("color", "");
                    wxString content = productNode->GetAttribute("content", "");
                    wxString kick = productNode->GetAttribute("kick", "no");


                    // Create the product instance
                    auto product = std::make_shared<Product>(&mGame);

                    // Convert placement to integer and accumulate it to the sum
                    std::string placementStr = placement.ToStdString();
                    placementStr.erase(std::remove(placementStr.begin(), placementStr.end(), '+'), placementStr.end());
                    int placementValue = std::stoi(placementStr);

                    placementSum -= placementValue * 1.2;
                    product->SetPlacement(placementSum);


                    // Set the shape, color, content, kick attributes
                    product->SetShape(shape.ToStdString());
                    product->SetColor(color.ToStdString());
                    product->SetContent(content.ToStdString());
                    product->SetKick(kick == "yes");

                    // Set the x coordinate using the conveyor's x coordinate
                    product->SetxCoord(std::stoi(x.ToStdString()));

                    // Add the product to the game
                    mGame.AddItem(product);
                }
                productNode = productNode->GetNext();
            }

            // After processing all product nodes, set the placement of the last added product
            //if (auto lastProduct = mGame.GetLastAddedProduct()) { // Assuming there's a method to get the last product
            //    lastProduct->SetPlacement(placementSum);  // Set the accumulated placement
            //}
        }

        if (nodeName.IsSameAs("beam"))
        {
            wxString x = itemNode->GetAttribute("x", "0");
            wxString y = itemNode->GetAttribute("y", "0");
            wxString sender = itemNode->GetAttribute("sender", "0");


            auto beam = std::make_shared<Beam>();
            beam->LoadFromXML(itemNode);
            auto ibeam = std::static_pointer_cast<Item>(beam);
            mGame.LoadItem(ibeam);
        }

        if (nodeName.IsSameAs("sensor"))
        {
            wxString x = itemNode->GetAttribute("x", "0");
            wxString y = itemNode->GetAttribute("y", "0");

            auto sensor = std::make_shared<Sensor>();
            sensor->LoadFromXML(itemNode);
            auto isensor = std::static_pointer_cast<Item>(sensor);
            mGame.LoadItem(isensor);
        }

        if (nodeName.IsSameAs("sparty"))
        {
            wxString x = itemNode->GetAttribute("x", "0");
            wxString y = itemNode->GetAttribute("y", "0");
            wxString height = itemNode->GetAttribute("height", "0");
            wxString pin = itemNode->GetAttribute("pin", "0,0");
            wxString kickDuration = itemNode->GetAttribute("kick-duration", "0.25");
            wxString kickSpeed = itemNode->GetAttribute("kick-speed", "1000");


            auto sparty = std::make_shared<Sparty>();
            sparty->LoadFromXML(itemNode);
            auto isparty = std::static_pointer_cast<Item>(sparty);
            mGame.LoadItem(isparty);
        }

        itemNode = itemNode->GetNext();
    }


    Refresh();
    return true;
}

void GameView::OnTimer(wxTimerEvent& event)
{
    // Calculate deltaTime (time since the last frame)
    static wxStopWatch stopwatch;
    double deltaTime = stopwatch.Time() / 1000.0; // Convert milliseconds to seconds
    stopwatch.Start(); // Restart the stopwatch

    // Update all items in the game
    for (auto& item : mGame.GetItems())
    {
        // Assuming mGame.GetItems() returns all items
        auto product = std::dynamic_pointer_cast<Product>(item);
        auto sparty = std::dynamic_pointer_cast<Sparty>(item);
        auto conveyor = std::dynamic_pointer_cast<ConveyorBelt>(item);

        if (product)
        {
            product->Update(deltaTime, 1);
        }
        else if (sparty)
        {
            sparty->Update(deltaTime);
        }
        else if (conveyor)
        {
            conveyor->Update(deltaTime);
        }
        else
        {
            item->Update(deltaTime);
        }
    }

    Refresh(); // Refresh the view regularly to see the new positions
}
