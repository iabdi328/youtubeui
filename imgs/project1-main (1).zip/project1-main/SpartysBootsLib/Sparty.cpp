/**
 * @file Sparty.cpp
 * @author George Faraj
 */

#include "pch.h"
#include "Sparty.h"


/// Image filenames
const std::wstring SpartyBackImage = L"images/sparty-back.png";
const std::wstring SpartyBootImage = L"images/sparty-boot.png";
const std::wstring SpartyFrontImage = L"images/sparty-front.png";

/// Constants for Sparty's boot movement
const double SpartyBootPivotX = 0.5;
const double SpartyBootPivotY = 0.55;
const double SpartyBootMaxRotation = 0.8;
const double SpartyKickPoint = 0.35;
const double SpartyBootPercentage = 0.80;

/// Pin-related constants
const int PinSize = 10;
const wxColour ConnectionColorZero = *wxBLACK;
const wxColour ConnectionColorOne = *wxRED;
const wxColour ConnectionColorUnknown = wxColour(128, 128, 128);

/**
 * Constructor
 */
Sparty::Sparty()
{
    mBackImage = std::make_shared<wxImage>(SpartyBackImage);
    mBootImage = std::make_shared<wxImage>(SpartyBootImage);
    mFrontImage = std::make_shared<wxImage>(SpartyFrontImage);
}

/**
 * Draw Sparty at the current position
 * @param gc Graphics context to draw on
 * @param pos Position to draw at
 */
void Sparty::Draw(wxGraphicsContext* gc, const wxPoint& pos)
{
    if (!mBackImage->IsOk() || !mBootImage->IsOk() || !mFrontImage->IsOk())
    {
        return;
    }

    // Lazy initialization of bitmaps
    if (mBack.IsNull())
    {
        mBack = gc->CreateBitmapFromImage(*mBackImage);
    }
    if (mBoot.IsNull())
    {
        mBoot = gc->CreateBitmapFromImage(*mBootImage);
    }
    if (mFront.IsNull())
    {
        mFront = gc->CreateBitmapFromImage(*mFrontImage);
    }

    // Calculate boot rotation based on kick time
    double rotation = 0;
    if (mKickTime > 0)
    {
        double kickProgress = mKickTime / mKickDuration;
        if (kickProgress < 0.5)
        {
            rotation = -SpartyBootMaxRotation * (kickProgress * 2);
        }
        else
        {
            rotation = -SpartyBootMaxRotation * ((1.0 - kickProgress) * 2);
        }
    }

    // Get image dimensions
    int width = mBackImage->GetWidth();
    int height = mBackImage->GetHeight();

    // Calculate scale to maintain aspect ratio
    double scale = mHeight / height;
    int scaledWidth = static_cast<int>(width * scale);
    int scaledHeight = static_cast<int>(height * scale);

    // Draw background
    gc->PushState();
    gc->DrawBitmap(mBack, mX - scaledWidth / 2, mY - scaledHeight / 2, scaledWidth, scaledHeight);
    gc->PopState();

    // Draw boot with rotation
    gc->PushState();
    // Move to pivot point
    gc->Translate(mX + scaledWidth * (SpartyBootPivotX - 0.5),
                  mY + scaledHeight * (SpartyBootPivotY - 0.5));
    gc->Rotate(rotation);
    gc->DrawBitmap(mBoot, -scaledWidth * SpartyBootPivotX,
                   -scaledHeight * SpartyBootPivotY,
                   scaledWidth, scaledHeight);
    gc->PopState();

    // Draw foreground
    gc->PushState();
    gc->DrawBitmap(mFront, mX - scaledWidth / 2, mY - scaledHeight / 2, scaledWidth, scaledHeight);
    gc->PopState();

    // After drawing Sparty, draw the pin
    DrawPin(gc);

    // Draw kick line for debugging
    /*
    int bootY = int(scaledHeight * SpartyBootPercentage);
    wxPen bootablePen(*wxGREEN, 3);
    gc->SetPen(bootablePen);
    gc->StrokeLine(mX - scaledWidth/2, mY - scaledHeight/2 + bootY,
                  mX + scaledWidth/2, mY - scaledHeight/2 + bootY);
    */
}

void Sparty::DrawPin(wxGraphicsContext* gc)
{
    // Draw the pin near Sparty's back - moved more to the left and up
    double backPinX = mX + mWidth / 3;
    double backPinY = mY;

    // Draw the pin circle at Sparty's back
    gc->SetPen(wxPen(ConnectionColorZero, LineWidth));
    gc->SetBrush(*wxWHITE_BRUSH);
    gc->DrawEllipse(backPinX - PinSize / 2, backPinY - PinSize / 2, PinSize, PinSize);

    // Small horizontal line from back pin
    double startVerticalX = backPinX + DefaultLineLength;
    gc->StrokeLine(backPinX, backPinY, startVerticalX, backPinY);

    // Vertical line up (staying to the right of Sparty)
    double topY = 20; // Moved up from 30 to 20 to be higher above scoreboard
    gc->StrokeLine(startVerticalX, backPinY, startVerticalX, topY);

    // Horizontal line across (avoiding scoreboard)
    gc->StrokeLine(startVerticalX, topY, mPinX, topY);

    // Vertical line down to input pin
    gc->StrokeLine(mPinX, topY, mPinX, mPinY);

    // Draw the input pin circle
    gc->DrawEllipse(mPinX - PinSize / 2, mPinY - PinSize / 2, PinSize, PinSize);

    // Draw the line extending left from input pin
    gc->StrokeLine(mPinX - DefaultLineLength, mPinY, mPinX, mPinY);
}

/**
 * Load the sparty data from an XML node
 * @param node The parent XML node
 * @return bool True if successful
 */
bool Sparty::LoadFromXML(wxXmlNode* node)
{
    if (node->GetName() != L"sparty")
    {
        return false;
    }

    // Load position and height
    long x, y, height;
    node->GetAttribute(L"x", L"0").ToLong(&x);
    node->GetAttribute(L"y", L"0").ToLong(&y);
    node->GetAttribute(L"height", L"0").ToLong(&height);

    mX = static_cast<double>(x);
    mY = static_cast<double>(y);
    mHeight = static_cast<double>(height);

    // Calculate width to maintain aspect ratio
    if (mBackImage->IsOk())
    {
        double aspectRatio = static_cast<double>(mBackImage->GetWidth()) /
            static_cast<double>(mBackImage->GetHeight());
        mWidth = mHeight * aspectRatio;
    }

    // Load pin position
    wxString pinStr = node->GetAttribute(L"pin", L"0");
    wxStringTokenizer tokenizer(pinStr, L",");
    if (tokenizer.CountTokens() == 2)
    {
        tokenizer.GetNextToken().ToLong(&x);
        tokenizer.GetNextToken().ToLong(&y);
        mPinX = static_cast<double>(x);
        mPinY = static_cast<double>(y);
    }

    // Load kick parameters
    node->GetAttribute(L"kick-duration", L"").ToDouble(&mKickDuration);
    node->GetAttribute(L"kick-speed", L"").ToDouble(&mKickSpeed);

    return true;
}

/**
 * Handle updates for animation
 * @param elapsed The time since the last update
 */
void Sparty::Update(double elapsed)
{
    if (mKickTime > 0)
    {
        mKickTime -= elapsed;
        if (mKickTime < 0)
        {
            mKickTime = 0;
        }
    }
}

/**
 * Set the state of the input pin
 * @param state The new pin state
 */
void Sparty::SetPinState(bool state)
{
    // Detect rising edge (0 to 1 transition)
    if (!mPrevPinState && state)
    {
        mKickTime = mKickDuration;
    }
    mPrevPinState = state;
}

/**
 * Check if a product at the given location should be kicked
 * @param productX X coordinate of the product
 * @param productY Y coordinate of the product
 * @return bool True if the product should be kicked
 */
bool Sparty::ShouldKickProduct(double productX, double productY) const
{
    // Only kick at the appropriate point in the animation
    if (mKickTime <= 0 || mKickTime > mKickDuration * (1.0 - SpartyKickPoint))
    {
        return false;
    }

    // Calculate boot height where kicking occurs
    double bootY = mY - mHeight / 2 + (mHeight * SpartyBootPercentage);

    // Check if product is at the right position
    const double tolerance = 10.0;
    return std::abs(productY - bootY) < tolerance &&
        productX >= mX - mWidth / 2 &&
        productX <= mX + mWidth / 2;
}
