/**
 * @file Game.cpp
 * @author Hector Dominguez Rojas
 * @author Owen Garcia
 * @author George Faraj
 * @author Brendan Adamski
 * @author Ismail Abdi
 */

#include "pch.h"
#include "Item.h"
#include "Game.h"
#include "ConveyorBelt.h"
#include "Scoreboard.h"


const int InitialX = 100;  // Initial X position for products
const int InitialY = 50;   // Initial Y position for products

using namespace std;

// Constructor
Game::Game()
{
    // Initialize game components
    Initialize();
}

/**
 * Initializes game components.
 */
void Game::Initialize()
{
    mPixelWidth = 1150;  // Default width if XML data is unavailable
    mPixelHeight = 800;  // Default height if XML data is unavailable
}

/**
 * Adds an item to the game.
 * @param item The item to add.
 */
void Game::AddItem(const std::shared_ptr<Item>& item)
{
    mItems.push_back(item);
}

/**
 * Draws the game.
 * @param graphics The graphics device to draw on.
 * @param width The width of the window.
 * @param height The height of the window.
 */
void Game::OnDraw(const std::shared_ptr<wxGraphicsContext>& graphics, int width, int height)
{
    auto scaleX = double(width) / double(mPixelWidth);
    auto scaleY = double(height) / double(mPixelHeight);
    mScale = std::min(scaleX, scaleY);

    mXOffset = (width - mPixelWidth * mScale) / 2.0;
    mYOffset = (height > mPixelHeight * mScale) ? (height - mPixelHeight * mScale) / 2.0 : 0;

    graphics->PushState();
    graphics->Translate(mXOffset, mYOffset);
    graphics->Scale(mScale, mScale);

    wxBrush background(*wxWHITE);
    graphics->SetBrush(background);
    graphics->DrawRectangle(0, 0, mPixelWidth, mPixelHeight);

    for (const auto& item : mItems) {
        wxPoint pos = item->GetPosition();
        item->Draw(graphics.get(), pos);
    }

    graphics->PopState();
}



void Game::ClearItems()
{
    mItems.clear();
}



void Game::LoadItem(std::shared_ptr<Item>& item)
{
    AddItem(item);
}


/**
 * Loads game settings and item properties from an XML node.
 * @param node The XML node containing game data.
 */
void Game::LoadFromXML(wxXmlNode* node)
{
    if (node->GetName() == "level") {
        wxString sizeAttr = node->GetAttribute("size", "1150,800");
        long width, height;

        wxStringTokenizer tokenizer(sizeAttr, ",");
        if (tokenizer.GetNextToken().ToLong(&width) && tokenizer.GetNextToken().ToLong(&height)) {
            mPixelWidth = width;
            mPixelHeight = height;
        }

        // Load other items and attributes as necessary
        ClearItems();
        for (auto child = node->GetChildren(); child; child = child->GetNext()) {
            // Process each child item node here as necessary
        }
    }
}



// GetConveyorBelt
std::shared_ptr<ConveyorBelt> Game::GetConveyorBelt() {
    auto it = std::find_if(mItems.begin(), mItems.end(), [](const auto& item) {
        return std::dynamic_pointer_cast<ConveyorBelt>(item) != nullptr;
    });

    if (it != mItems.end()) {
        auto conveyorBelt = std::dynamic_pointer_cast<ConveyorBelt>(*it);

        // Display the conveyor status
        if (conveyorBelt->IsStarted()) {
        } else {
        }

        return conveyorBelt;
    }

    // If no conveyor belt is found, ask the user if they want to continue
    int answer = wxMessageBox("No conveyor belt found in the game. Do you want to continue?",
                               "Conveyor Status",
                               wxYES_NO | wxICON_WARNING);

    if (answer == wxNO) {
        // Handle the case where the user does not want to continue
        // For example, you could exit the game or return a special value
        return nullptr; // Or handle appropriately
    }

    return nullptr; // If continuing, still return nullptr
}

/**
 * Moves a clicked item to the "front" of the screen.
 * @param item Item to move.
 */
void Game::MoveToFront(std::shared_ptr<Item> item)
{
    auto loc = find(begin(mItems), end(mItems), item);
    if (loc != end(mItems))
    {
        mItems.erase(loc);
        mItems.push_back(item);
    }
}

/**
 * Test an x,y click location to see if it clicked.
 * To be used on an item in the game; mostly gates.
 * @param x X location in pixels.
 * @param y Y location in pixels.
 * @returns Pointer to item we clicked on or nullptr if none.
*/
std::shared_ptr<Item> Game::HitTest(wxPoint pos)
{
    for (auto i = mItems.rbegin(); i != mItems.rend();  i++)
    {
        if ((*i)->HitTest(pos))
        {
            return *i;
        }
    }
    return nullptr;
}
