/**
* @file Product.cpp
 * @author Brendan Adamski
 */

#include "pch.h"
#include "Product.h"
#include "ConveyorBelt.h"



using namespace std;


Product::~Product() = default;

void Product::LoadImage(const std::wstring& filename) {
    // Attempt to load the image file
    mProductImage = std::make_unique<wxImage>();
    if (!mProductImage->LoadFile(filename, wxBITMAP_TYPE_ANY)) {
        mProductBitmap = nullptr; // No bitmap to draw
    } else {
        mProductBitmap = std::make_unique<wxBitmap>(*mProductImage);
    }
}

void Product::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
    wxDouble yPos = mPlacement; // Use placement for the y-coordinate

    // Draw the shape background if available
    if (!mShape.empty()) {
        gc->SetBrush(wxBrush(mColor)); // Set the color for the shape

        if (mShape == "square") {
            gc->DrawRectangle(mXCoord - 50, yPos - 50, 100, 100); // Draw a square
        } else if (mShape == "circle") {
            gc->DrawEllipse(mXCoord - 50, yPos - 50, 100, 100); // Draw a circle
        } else if (mShape == "diamond") {
            const wxPoint2DDouble diamond[4] = {
                {static_cast<wxDouble>(mXCoord), static_cast<wxDouble>(static_cast<int>(yPos - 50))}, // Top point
                {static_cast<wxDouble>(mXCoord + 50), yPos}, // Right point
                {static_cast<wxDouble>(mXCoord), yPos + 50}, // Bottom point
                {static_cast<wxDouble>(mXCoord - 50), yPos} // Left point
            };
            gc->DrawLines(4, diamond); // Draw the diamond shape
        }
    }

    // Draw the image on top if available
    if (mProductBitmap) {
        double width = mProductBitmap->GetWidth();
        double height = mProductBitmap->GetHeight();
        gc->DrawBitmap(*mProductBitmap, mXCoord - width / 2, yPos - height / 2, width, height);
    }
}




bool Product::HitTest(int x, int y) const {
    if (mProductBitmap) {
        double width = mProductBitmap->GetWidth();
        double height = mProductBitmap->GetHeight();
        double testX = x - mPosition.x + width / 2;
        double testY = y - mPosition.y + height / 2;

        return !(testX < 0 || testY < 0 || testX >= width || testY >= height) &&
               !mProductImage->IsTransparent(static_cast<int>(testX), static_cast<int>(testY));
    } else {
        // Implement hit testing for shapes (optional)
        return false; // You can add your own hit testing logic for shapes
    }
}

void Product::SetAttributes(const std::string& shape, const std::string& color, const std::string& content) {
    mShape = shape;
    mContent = content;
    SetColor(color);  // Set color using the new SetColor method

    // Load the image based on content
    SetContent(content);
}

// SetKick implementation
void Product::SetKick(bool kick) {
    mKick = kick;
}

// SetContent implementation
void Product::SetContent(const std::string& content) {
    mContent = content;

    // Only attempt to load an image if content is not empty
    if (!content.empty()) {
        // Construct the filename based on the content
        std::wstring filename = L"images/" + std::wstring(content.begin(), content.end()) + L".png";
        LoadImage(filename); // Load the image using the new method
    } else {
        mProductImage = nullptr;
        mProductBitmap = nullptr;
    }
}


// SetShape implementation
void Product::SetShape(const std::string& shape) {
    mShape = shape;
}

// SetPlacement implementation
void Product::SetPlacement(int placement) {
    mPlacement = placement;
    mOrigionalPlacement = mPlacement;
}

void Product::SetColor(const std::string& color) {
    if (color == "red") {
        mColor = *wxRED;
    } else if (color == "blue") {
        mColor = *wxBLUE;
    } else if (color == "green") {
        mColor = *wxGREEN;
    } else if (color == "white") {
        mColor = *wxWHITE;
    } else {
        mColor = *wxBLACK;  // Default color if unknown
    }
}

void Product::Update(double deltaTime, bool isConveyorStarted) {
    // Use GetConveyorBelt to check the conveyor status
    auto conveyorBelt = mGame->GetConveyorBelt();

    // Check if the conveyor belt is started
    if (conveyorBelt && conveyorBelt->IsStarted()) {
        // If the conveyor belt is started, adjust mPlacement to move the product
        double speed = 100.0; // Speed in pixels per second
        mPlacement += speed * deltaTime;
    }        if (conveyorBelt && !conveyorBelt->IsStarted())
    {
        mPlacement = mOrigionalPlacement;
    }
}


void Product::SetxCoord(int xCoord) {
    mXCoord = xCoord;  // Store the x-coordinate in the member variable
}
