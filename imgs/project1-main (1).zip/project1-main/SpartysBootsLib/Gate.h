/**
 * @file Gate.h
 * @author Owen Garcia
 */

#ifndef GATE_H
#define GATE_H

#include "Item.h"
#include "Pin.h"


class Gate : public Item {
protected:
	wxSize mSize;
	Pin* inputPin1 = nullptr;
	Pin* inputPin2 = nullptr;
	Pin* outputPin = nullptr;

public:
	explicit Gate(const wxSize& size) : mSize(size) {}
	virtual ~Gate() { delete inputPin1; delete inputPin2; delete outputPin; }

	virtual void ComputeOutput() = 0;
	virtual void Draw(wxGraphicsContext* gc, const wxPoint& pos) = 0;
	void Update(double elapsed);

	// void Accept(ItemVisitor* visitor) override{};
};

#endif // GATE_H
