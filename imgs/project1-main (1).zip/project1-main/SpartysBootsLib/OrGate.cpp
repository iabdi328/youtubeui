/**
 * @file OrGate.cpp
 * @author Owen Garcia
 */
#include "pch.h"
#include "OrGate.h"


OrGate::OrGate() : Gate(wxSize(75, 50)) {
    // Initialize pins for OR gate
    inputPin1 = new Pin(States::Unknown, wxPoint(-40, 25), false);
    inputPin2 = new Pin(States::Unknown, wxPoint(-40, -25), false);
    outputPin = new Pin(States::Unknown, wxPoint(40, 0), true);
}

OrGate::~OrGate() {
    delete inputPin1;
    delete inputPin2;
    delete outputPin;
}

void OrGate::ComputeOutput() {
    // OR gate logic
    States input1 = inputPin1->GetState();
    States input2 = inputPin2->GetState();

    if (input1 == States::One || input2 == States::One) {
        outputPin->SetState(States::One);
    } else if (input1 == States::Zero && input2 == States::Zero) {
        outputPin->SetState(States::Zero);
    } else {
        outputPin->SetState(States::Unknown);
    }
}

void OrGate::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
    auto path = gc->CreatePath();

    auto x = pos.x;
    auto y = pos.y;
    auto w = mSize.GetWidth();
    auto h = mSize.GetHeight();

    wxPoint2DDouble p1(x - w / 2, y + h / 2);
    wxPoint2DDouble p2(x + w / 2, y);
    wxPoint2DDouble p3(x - w / 2, y - h / 2);

    auto controlPointOffset1 = wxPoint2DDouble(w * 0.5, 0);
    auto controlPointOffset2 = wxPoint2DDouble(w * 0.75, 0);
    auto controlPointOffset3 = wxPoint2DDouble(w * 0.2, 0);

    path.MoveToPoint(p1);
    path.AddCurveToPoint(p1 + controlPointOffset1, p1 + controlPointOffset2, p2);
    path.AddCurveToPoint(p3 + controlPointOffset2, p3 + controlPointOffset1, p3);
    path.AddCurveToPoint(p3 + controlPointOffset3, p1 + controlPointOffset3, p1);
    path.CloseSubpath();

    gc->SetPen(*wxBLACK_PEN);
    gc->SetBrush(*wxWHITE_BRUSH);
    gc->DrawPath(path);

    inputPin1->Draw(gc, pos);
    inputPin2->Draw(gc, pos);
    outputPin->Draw(gc, pos);
}

/**
 * Test to see if we hit this object with a mouse.
 * @param pos Position to test.
 * @return true if hit.
 */
bool OrGate::HitTest(wxPoint pos)
{
    // Calculate the position relative to the gate’s center
    int testX = pos.x - GetPosition().x;
    int testY = pos.y - GetPosition().y;

    // Get gate width and height
    int w = mSize.GetWidth();
    int h = mSize.GetHeight();

    // Check if the point is within bounding box (for efficiency)
    if (testX < -w / 2 || testX > w / 2 || testY < -h / 2 || testY > h / 2)
    {
        return false; // Outside bounding box
    }

    // Define points approximating the OR gate shape
    wxPoint p1(-w / 2, h / 2);
    wxPoint p2(w / 2, 0);
    wxPoint p3(-w / 2, -h / 2);

    // Simple approximation of shape using a triangle region
    return testX >= p1.x && testX <= p2.x && testY >= p3.y && testY <= p1.y;
}
