/**
 * @file Product.h
 * @author Brendan Adamski
 *
 */

#ifndef PRODUCT_H
#define PRODUCT_H

#include "Item.h"  // Include Item class
#include "Game.h"

class ConveyorBelt; // Forward declaration
class Game;
class Product : public Item {  // Inherit from Item

private:
    wxBitmap mBitmap;
    Game* mGame;
    std::shared_ptr<wxImage> mProductImage; // Product image
    std::unique_ptr<wxBitmap> mProductBitmap; // Product bitmap
    double mSpeed; // Product speed
    std::string mContent, mShape;
    wxColour mColor; // Updated to wxColour for display purposes
    bool mKick;
    int mPlacement, mOrigionalPlacement, mXCoord;

public:
    Product(Game* game) : mGame(game) { // Pass the Game pointer to the constructor
        mProductImage = nullptr; // Initialize to nullptr
        mProductBitmap = nullptr; // Initialize to nullptr
     }

    ~Product() override;
    void LoadImageW(const std::wstring& filename);

    // Override Draw from Item
    void Draw(wxGraphicsContext* gc, const wxPoint& pos) override;
    bool HitTest(int x, int y) const;

    wxXmlNode* XmlSave(wxXmlNode* node);
    void XmlLoad(wxXmlNode* node);

    void Update(double deltaTime, bool isConveyorStarted);
    void SetxCoord(int xCoord);

    void SetAttributes(const std::string& shape, const std::string& color, const std::string& content);
    void SetColor(const std::string& color); // New method to set color

    // Individual setters for each attribute
    void SetKick(bool kick);
    void SetContent(const std::string& content);
    void SetShape(const std::string& shape);
    void SetPlacement(int placement);
    int GetPlacement() { return mPlacement; }

    int GetYCoord() { return mProductBitmap->GetHeight(); }
	int GetxCoord() const { return mXCoord; }

    void SetLocation(double x, double y) { mPosition = wxPoint(x, y); }  // Use inherited mPosition

    /**
    * Accept a visitor
    * @param visitor The visitor we accept
    */
    // void Accept(ItemVisitor* visitor) override { visitor->VisitProduct(this); }
};



#endif // PRODUCT_H
