/**
 * @file Level.cpp
 * @author Ismail Abdi
 */
 
// Level.cpp
#include "pch.h"
#include "Level.h"


bool Level::LoadFromXML(const wxString& filePath) {
 wxXmlDocument xmlDoc;
 if (!xmlDoc.Load(filePath)) {
  return false;
 }

 if (xmlDoc.GetRoot()->GetName() != "level") {
  return false;
 }

 return true;
}

bool Level::Save(const wxString& filePath) {
 wxXmlDocument xmlDoc;
 auto root = new wxXmlNode(wxXML_ELEMENT_NODE, "level");
 xmlDoc.SetRoot(root);

 auto itemNode = new wxXmlNode(wxXML_ELEMENT_NODE, "item");
 itemNode->AddAttribute("type", "conveyor");
 itemNode->AddAttribute("x", "100");
 itemNode->AddAttribute("y", "200");
 root->AddChild(itemNode);

 if (!xmlDoc.Save(filePath, wxXML_NO_INDENTATION)) {
  return false;
 }

 return true;
}

