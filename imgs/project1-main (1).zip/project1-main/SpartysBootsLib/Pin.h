/**
 * @file Pin.h
 * @author Owen Garcia
 */

#ifndef PIN_H
#define PIN_H



enum class States { One, Zero, Unknown };

/// Maximum offset of Bezier control points relative to line ends
static constexpr double BezierMaxOffset = 200;

/// Line with for drawing lines between pins
static const int LineWidth = 3;

/// Default length of line from the pin
static const int DefaultLineLength = 20;

class Pin {
private:
	States mState;
	wxPoint mLocation;
	bool mDragging = false;
	bool mIsOutput; // True if this pin is an output pin
	wxPoint mWireEnd;
	Pin* mConnectedPin = nullptr;

public:
	Pin(States state, const wxPoint& location, bool isOutput)
		: mState(state), mLocation(location), mIsOutput(isOutput) {}

	States GetState() const { return mState; }
	void SetState(States state) { mState = state; }

	bool HitTest(int x, int y) const;

	void StartDragging(int x, int y);
	void SetWireEnd(int x, int y);
	void StopDragging();
	bool IsOutput() const { return mIsOutput; }

	// Connects this pin to another pin
	void ConnectTo(Pin* inputPin);

	void Draw(wxGraphicsContext* gc, const wxPoint& gatePos) const;
};

#endif // PIN_H
