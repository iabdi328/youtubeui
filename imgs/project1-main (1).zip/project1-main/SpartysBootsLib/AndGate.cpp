/**
 * @file AndGate.cpp
 * @author Owen Garcia
 */
#include "pch.h"
#include "AndGate.h"


AndGate::AndGate() : Gate(wxSize(75, 50)) {
    inputPin1 = new Pin(States::Unknown, wxPoint(-40, 25), false);
    inputPin2 = new Pin(States::Unknown, wxPoint(-40, -25), false);
    outputPin = new Pin(States::Unknown, wxPoint(40, 0), true);
}

AndGate::~AndGate() {
    delete inputPin1;
    delete inputPin2;
    delete outputPin;
}

void AndGate::ComputeOutput() {
    States input1 = inputPin1->GetState();
    States input2 = inputPin2->GetState();

    if (input1 == States::One && input2 == States::One) {
        outputPin->SetState(States::One);
    } else if (input1 == States::Zero || input2 == States::Zero) {
        outputPin->SetState(States::Zero);
    } else {
        outputPin->SetState(States::Unknown);
    }
}

void AndGate::Draw(wxGraphicsContext* gc, const wxPoint& pos) {
    auto path = gc->CreatePath();
    auto x = pos.x;
    auto y = pos.y;
    auto w = mSize.GetWidth();
    auto h = mSize.GetHeight();

    wxPoint2DDouble p1(x - w / 2, y + h / 2);
    wxPoint2DDouble p2(x + w / 2, y);
    wxPoint2DDouble p3(x - w / 2, y - h / 2);

    auto controlPointOffset1 = wxPoint2DDouble(w * 0.5, 0);
    auto controlPointOffset2 = wxPoint2DDouble(w * 0.75, 0);

    path.MoveToPoint(p1);
    path.AddCurveToPoint(p1 + controlPointOffset1, p1 + controlPointOffset2, p2);
    path.AddCurveToPoint(p3 + controlPointOffset2, p3 + controlPointOffset1, p3);
    path.MoveToPoint(p1);
    path.AddLineToPoint(p3);
    path.CloseSubpath();

    gc->SetPen(*wxBLACK_PEN);
    gc->SetBrush(*wxWHITE_BRUSH);
    gc->DrawPath(path);

    inputPin1->Draw(gc, pos);
    inputPin2->Draw(gc, pos);
    outputPin->Draw(gc, pos);
}

// std::shared_ptr<Pin> AndGate::HitTest(int x, int y) {
//     if (inputPin1->HitTest(x, y)) return std::shared_ptr<Pin>(inputPin1);
//     if (inputPin2->HitTest(x, y)) return std::shared_ptr<Pin>(inputPin2);
//     if (outputPin->HitTest(x, y)) return std::shared_ptr<Pin>(outputPin);
//     return nullptr;
// }

/**
 * Test to see if we hit this object with a mouse.
 * @param pos Position to test.
 * @return true if hit.
 */
bool AndGate::HitTest(wxPoint pos)
{
    // Calculate the position relative to the gate’s center
    int testX = pos.x - GetPosition().x;
    int testY = pos.y - GetPosition().y;

    // Get gate width and height
    int w = mSize.GetWidth();
    int h = mSize.GetHeight();

    // Check if the point is within bounding box (for efficiency)
    if (testX < -w / 2 || testX > w / 2 || testY < -h / 2 || testY > h / 2)
    {
        return false; // Outside bounding box
    }

    // Define the curve shape of the AND gate path
    wxPoint p1(-w / 2, h / 2);
    wxPoint p2(w / 2, 0);
    wxPoint p3(-w / 2, -h / 2);

    // Simple approximation of path shape using a triangle (you can refine with curves if needed)
    return testX >= p1.x && testX <= p2.x && testY >= p3.y && testY <= p1.y;
}