/**
 * @file GameView.h
 * @author Ismail Abdi
 * @author Owen Garcia
 *
 */

#ifndef GAMEVIEW_H
#define GAMEVIEW_H

#include "ConveyorBelt.h"
#include "Game.h"
/**
 * @class GameView
 * @brief A simple game view for the window.
 */
class GameView : public wxWindow {
private:
	Game mGame;                           // Game object
	wxTimer mTimer;                      // Timer for refreshing the view

	/// Any item we are currently dragging.
	std::shared_ptr<Item> mGrabbedItem;

	void OnOrGate(wxCommandEvent& event);
	void OnAndGate(wxCommandEvent& event);
	void OnNotGate(wxCommandEvent& event);

public:
	void Initialize(wxFrame* parent);
	void OnPaint(wxPaintEvent& event);
	void OnTimer(wxTimerEvent& event);
	void OnMouseDown(wxMouseEvent& event);
	void OnMouseUp(wxMouseEvent& event);
	void OnMouseMove(wxMouseEvent& event);
	bool LoadFromXML(const wxString& filePath);
};

#endif //GAMEVIEW_H
