/**
 * @file ids.h
 * @author Owen Garcia
 *
 * ID values for our program.
 */

#ifndef PROJECT1_IDS_H
#define PROJECT1_IDS_H

/**
 * IDs for each gate.
 */
enum IDs {
	IDM_ADDGATEOR = wxID_HIGHEST + 1,
	IDM_ADDGATEAND,
	IDM_ADDGATENOT,
	IDM_LOAD_LEVEL0, // Starting ID for levels menu
	IDM_LOAD_LEVEL1,
	IDM_LOAD_LEVEL2,
	IDM_LOAD_LEVEL3,
	IDM_LOAD_LEVEL4,
	IDM_LOAD_LEVEL5,
	IDM_LOAD_LEVEL6,
	IDM_LOAD_LEVEL7,
	IDM_LOAD_LEVEL8,
};

#endif //PROJECT1_IDS_H