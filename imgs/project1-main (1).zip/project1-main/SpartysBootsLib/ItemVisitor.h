/**
 * @file ItemVisitor.h
 * @author Hector Dominguez Rojas
 *
 *
 */
 
#ifndef ITEMVISITOR_H
#define ITEMVISITOR_H


class Sensor;
class ConveyorBelt;
class Product;
class Beam;
class Sparty;
class Scoreboard;

class ItemVisitor {
protected:
  ItemVisitor() {}
private:

public:
    virtual ~ItemVisitor() {}

    virtual void VisitSensor(Sensor* sensor) {}

    virtual void VisitConveyorBelt(ConveyorBelt* belt) {}

    virtual void VisitProduct(Product* product) {}

    virtual void VisitBeam(Beam* beam) {}

    virtual void VisitSparty(Sparty* sparty) {}

    virtual void VisitScoreboard(Scoreboard* scoreboard) {}
};



#endif //ITEMVISITOR_H
