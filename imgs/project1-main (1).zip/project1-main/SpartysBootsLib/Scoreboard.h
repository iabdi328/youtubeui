/**
 * @file Scoreboard.h
 * @author George Faraj
 * @author Brendan Adamski
 *
 * Class for the game scoreboard that loads and displays game information.
 * Loads position and scoring parameters from XML level files and displays
 * the current level number, score, and game instructions to indicate
 * the level progress.
 */

#ifndef SCOREBOARD_H
#define SCOREBOARD_H

#include "Item.h"


class Scoreboard : public Item {
private:
    const wxSize ScoreboardSize = wxSize(380, 100);
    const int SpacingScoresToInstructions = 40;

    int mLevelState;
    int mGameScore;
    wxString mInstruction;
    int mGoodScore;
    int mBadScore;

public:
    Scoreboard();
    void Draw(wxGraphicsContext* graphics, const wxPoint& pos) override;
    void DrawText(wxGraphicsContext* graphics, const wxString& text, double x, double y, int fontSize,
                  const wxColour& color);

    // Load attributes from XML
    void LoadFromXML(wxXmlNode* node);

    // Setter methods
    void SetPosition(const wxPoint& pos);
    void SetGoodScore(int score);
    void SetBadScore(int score);
    void SetInstruction(const wxString& instruction);
    void SetLevelState(int levelState);

    // void Accept(ItemVisitor* visitor) override{};
};

#endif // SCOREBOARD_H
