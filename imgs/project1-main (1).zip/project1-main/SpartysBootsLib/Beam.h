/**
* @file Beam.h
* @author Hector Dominguez Rojas
 * @brief Beam class definition
 */

#ifndef BEAM_H
#define BEAM_H

#pragma once
#include "Item.h"
#include "Product.h"


class Product;

class Beam : public Item {
private:
    double mX, mY, mHeight, mWidth;
    double mRotation = M_PI;
    bool mOutput = false;
    std::shared_ptr<wxImage> mGreenImage;
    std::shared_ptr<wxImage> mRedImage;

    std::shared_ptr<wxImage> mImage;

    wxGraphicsBitmap mSender;
    wxGraphicsBitmap mReceiver;

public:
    Beam();
    void Draw(wxGraphicsContext* gc, const wxPoint& pos) override;
    bool IsBroken(const std::shared_ptr<Product>& product);
    void Update(bool state);
    bool LoadFromXML(wxXmlNode* node);

    /**
    * Accept a visitor
    * @param visitor The visitor we accept
    */
    // void Accept(ItemVisitor* visitor) override { visitor->VisitBeam(this); }
};

#endif // BEAM_H
