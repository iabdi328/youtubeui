/**
 * @file Level.h
 * @author Ismail Abdi
 *
 *
 */
 
// Level.h
#ifndef LEVEL_H
#define LEVEL_H



class Level {
public:
 Level() = default;
 bool LoadFromXML(const wxString& filePath);
 bool Save(const wxString& filePath);
};

#endif // LEVEL_H
