/**
 * @file ConveyorBelt.h
 * @author Brendan Adamski
 * @author Owen Garcia
 * @author Ismail Abdi
 */

#ifndef CONVEYORBELT_H
#define CONVEYORBELT_H

#include "Item.h"
#include "Beam.h"


class Product;
class Beam;
/**
 * Class representing the conveyor belt system.
 * Handles drawing, updating, and managing the conveyor's products.
 */
class ConveyorBelt : public Item {
private:
    /// The beam
    std::shared_ptr<Beam> mBeam;
//    std::shared_ptr<Sensor> mSensor;

    /// The list of products on the conveyor belt
    std::vector<std::shared_ptr<Product>> mProducts;

    /// The conveyor node
    wxXmlNode* mConveyorNode;

    /// Background image of the conveyor
    std::shared_ptr<wxImage> mBackgroundImage;
    std::shared_ptr<wxImage> mBeltImage;
    std::shared_ptr<wxImage> mPanelStoppedImage;
    std::shared_ptr<wxImage> mPanelStartedImage;

    /// Bitmap representations for efficient drawing
    wxGraphicsBitmap mBackgroundBitmap;
    wxGraphicsBitmap mBeltBitmap;
    wxGraphicsBitmap mPanelBitmap;

    /// Conveyor position
    wxPoint mPosition;

    /// Additional variable to manage belt movement visual
    int mBeltPositionY = 400;

    /// Conveyor size
    int mWidth, mOriginalWidth;
    int mHeight, mOriginalHeight;

    /// Conveyor speed
    int mSpeed;

    /// Panel location relative to the conveyor
    wxPoint mPanelLocation;

    /// Random number generator for product placement or movement
    std::mt19937 mRandom;

    /// Conveyor belt state flag
    bool mIsStarted = false;

    /// Signals that the conveyor belt is ready to stop
    bool mIsEnding = false;

    // Define rectangles for button locations
    const wxRect StartButtonRect = wxRect(27, 20, 70, 30);
    const wxRect StopButtonRect = wxRect(27, 55, 70, 30);

    wxSound mConveyorLoopSound;
    bool mIsSoundPlaying;

public:
    /// Constructor
    ConveyorBelt();

    ~ConveyorBelt();
    void Stop();
    void EndSequence(double elapsed);

    /// Draw the conveyor belt and its products
    void Draw(wxGraphicsContext* gc, const wxPoint& pos);
    void OnClick(wxMouseEvent& event);

    /// Add a product to the conveyor belt
    void Add(const std::shared_ptr<Product>& product);

    /// Clear all products from the conveyor belt
    void Clear();

    /// Load the conveyor belt properties from an XML node
    bool LoadFromXML(wxXmlNode* node);

    /// Update product positions for animation
    void Update(double elapsed);

    void XmlProduct(wxXmlNode* node);
    bool IsWithinBounds(const wxPoint& pos) const;
    bool IsStarted() const;

    void SetBeam(const std::shared_ptr<Beam>& beam)
    {
        mBeam = beam;
    }
    std::shared_ptr<Beam> GetBeam() const
    {
        return mBeam;
    }

    /**
    * Accept a visitor
    * @param visitor The visitor we accept
    */
    // void Accept(ItemVisitor* visitor) override { visitor->VisitConveyorBelt(this); }

    //    void SetSensor(std::shared_ptr<Sensor> sensor)
    //    {
    //        mSensor = sensor;
    //    }
};

#endif // CONVEYORBELT_H
