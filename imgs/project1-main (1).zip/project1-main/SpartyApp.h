/**
* @file SpartyApp.h
 * @author Ismail Abdi
 * @brief Main application class for Sparty's Boots.
 *
 */

#ifndef SPARTYAPP_H
#define SPARTYAPP_H



class SpartyApp : public wxApp {
private:

public:
 virtual bool OnInit();
 int OnExit();


};



#endif //SPARTYAPP_H
